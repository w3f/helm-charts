{{/* Returns the app name */}}
{{- define "app.name" -}}
{{- default .Release.Name .Values.nameOverride -}}
{{- end }}

{{/* Returns the name of the TLS secret */}}
{{- define "app.tls-secret-name" -}}
{{ .Release.Name }}-tls
{{- end }}
