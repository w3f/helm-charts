{{/* The release's resource name: the override, or the release name with the chart name unless it already carries it. */}}
{{- define "polstead.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else if contains .Chart.Name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/* The labels every resource carries; takes the root context. */}}
{{- define "polstead.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | quote }}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/* The labels a selector matches on: takes a dict of `root` and `component`. */}}
{{- define "polstead.selectorLabels" -}}
app.kubernetes.io/name: {{ .root.Chart.Name }}
app.kubernetes.io/instance: {{ .root.Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- end -}}

{{/* The miner's Service name for a chain: takes a dict of `root` and `chain`. */}}
{{- define "polstead.minerName" -}}
{{ include "polstead.fullname" .root }}-miner-{{ .chain }}
{{- end -}}

{{/*
    The app's non-secret environment: the `config` values as given, plus what the chart knows better than the
    operator does, namely the URL of each miner it deploys and the callback URL of the ingress host.
*/}}
{{- define "polstead.env" -}}
{{- $env := dict -}}
{{- range $name, $value := .Values.config -}}
{{- if $value -}}{{- $_ := set $env $name (toString $value) -}}{{- end -}}
{{- end -}}
{{- range $chain, $miner := .Values.miners.chains -}}
{{- if $miner.enabled -}}
{{- $_ := set $env (printf "%s_MINER_URL" (upper $chain)) (printf "http://%s:%d" (include "polstead.minerName" (dict "root" $ "chain" $chain)) (int $.Values.miners.port)) -}}
{{- end -}}
{{- end -}}
{{- if and (not $env.OIDC_REDIRECT_URL) .Values.ingress.enabled .Values.ingress.host -}}
{{- $_ := set $env "OIDC_REDIRECT_URL" (printf "%s://%s/auth/callback" (ternary "https" "http" .Values.ingress.tls) .Values.ingress.host) -}}
{{- end -}}
{{- $_ := set $env "PORT" (toString .Values.port) -}}
{{- toYaml $env -}}
{{- end -}}
