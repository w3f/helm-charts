{{- define "app.imagePullSecret" }}
{{- printf "{\"auths\": {\"%s\": {\"auth\": \"%s\"}}}" .Values.image.private.server (printf "%s:%s" .Values.image.private.username .Values.image.private.password | b64enc) | b64enc }}
{{- end }}